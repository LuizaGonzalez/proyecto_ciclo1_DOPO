import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;
import java.util.Collections;
import java.util.Comparator;
import java.awt.Color;

/**
 * Ruta de seda con robots y tiendas que guardan montones de tengues, 
 * en donde cada robot se mueve para recolectarlas y tener una ganancia.
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */
public class silkRoad{
    
    private static final String[] color = {"red", "yellow", "blue", "green", "magenta", "black", "darkGray", "lightGray", "orange", "cyan"};
    private int length;
    private int location;
    private int StartTenges;
    private int currentTenges;
    private int meters;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private int totalProfit;
    private boolean isVisible;
    private boolean simulationRunning;
    private boolean lastOperationSuccess;
    
    /**
     * Contructor de la clase silkBoard.
     * @param length longitud de la ruta seda.
     */
    public silkRoad(int length){
        this.length = length;
        this.location = 50;
        this.StartTenges = 0;
        this.currentTenges = 0;
        this.meters = 0;
        stores =  new ArrayList<>();
        robots = new ArrayList<>();
        this.totalProfit = 0;
        this.isVisible = false;
        this.simulationRunning = true;
        this.lastOperationSuccess = true;
        
    }
    
    /**
     * Metodo para ubicar una tienda con su respectivo tenges. 
     * @param location posicion de la tienda.
     * @param tenges Son las monedas de Kazajistan.
     */
    public void placeStore(int location, int tenges){
        
        if (location < 0 || location > length){
            System.out.println("la locazion que deseas, esta por fuera del rango");
            return;
        }
        
        for (Store tienda : stores){
            if (tienda.getLocationStore() == location){
                System.out.println("Ya exixte una tienda en esta ubicacion");
                return;
            }
        }
        Store newStore = new Store(location,tenges);
        stores.add(newStore);
        resupplyStores();
    }

    /**
     * Metodo para eliminar una tienda dada su posicion.
     * @param location bposicion de la tienda.
     */
    public void removeStore(int location){
        for (int i = 0; i < stores.size(); i++) {
            Store tienda = stores.get(i);
            if (tienda.getLocationStore() == location){
                stores.remove(tienda);
                return;
            }
        }
    }
    
    /**
     * Metodo para ubicar un robot.
     * @param location posicion del robot.
     */
    public void placeRobot(int location){
        if (location<0 || location > length){
            System.out.println("la locazion que deseas, esta por fuera del rango");
            return;
        }
        
        for(Robot r : robots){
            if(r.getStartLocationRobot()== location ){
                System.out.println("Ya exixte un robot en esta ubicacion");
                return;
            }
        }
        
        Robot newRobot = new Robot(location);
        robots.add(newRobot);
        resupplyStores();
    }
    
    /**
     * Metodo para eliminar un robot.
     * @param location posicion del robot.
     */
    public void removeRobot(int location){
        for (int i = 0;i<robots.size();i++){
            Robot r = robots.get(i);
            if (r.getStartLocationRobot() == location){
                robots.remove(r);
                return;
            }
            
        }
        
    }
    
    /**
     * Metodo para mover un robot.
     * @param location posicion del robot.
     * @param meters metros que se movera el robot.
     */
    public void moveRobot(int location, int meters){
        if (location<0 ||location> length){
            System.out.println("No puedes mover el robot, ubicacion por fuera del rango");
            return;
        }
        Robot robotMove = null;
        for (Robot roro : robots){
            if(roro.getStartLocationRobot() == location || roro.getCurrentLocationRobot() == location){
                robotMove = roro;
            }
        }
       
        int newLocation = robotMove.getCurrentLocationRobot() + meters;
            
        if (newLocation<0 ||newLocation> length){
            System.out.println("No puedes mover el robot, ubicacion por fuera del rango");
            return;
        }
        
        for (Robot robit : robots){
            
            if ((newLocation == robit.getStartLocationRobot() || newLocation == robit.getCurrentLocationRobot())&& robit != robotMove){
                System.out.println("Esta ubicación ya tiene un robot");
                return;
            }    
        }
        robotMove.setCurrentLocationRobot(newLocation);
    }
        
    /**
     * Metodo para reabastecer las tiendas.
     */
    public void resupplyStores(){
        if (stores.isEmpty()){
            System.out.println("No hay tiendas");
            return;
        }
        
        for (Store store : stores){
           int resupplyTenges = 0;
           if (store.getLocationStore() % 2 == 0 ){
               resupplyTenges = 50;
           } else{
               resupplyTenges = 80;
           }
           store.addTenges(resupplyTenges);
        }
       
    }
    
    /**
     * Metodo para retornar los robots a sus posiciones iniciales.
     */
    public void returnRobots(){
       if (robots.isEmpty()){
           System.out.println("No hay robots");
           return;
       }
       
       for (Robot robit : robots){
           int startLocation = robit.getStartLocationRobot();
           if(robit.getCurrentLocationRobot() != robit.getStartLocationRobot()){
               robit.setCurrentLocationRobot(startLocation);
           }
       }
       resupplyStores();   
       
    }
    
    /**
     * Metodo para reiniciar la ruta de seda: tiendas y robots como fueron adicionados.
     * 
     */
    public void reboot(){
        // robot a sus posiciones iniciales
        returnRobots();
        //reabastecer
        resupplyStores();
        // ganancias
        totalProfit = 0;
    }
    
    /**
     * Metodo para consultar las ganancias obtenidas.
     */
    public void profit(){
        System.out.println("Ganancia total: " + totalProfit + " tenges");
    }
    
      /**
     * Metodo para ordenar por localizacion de menor a mayor.[location,tenges]
     */
    public int[][] stores() {
        Collections.sort(stores, Comparator.comparingInt(Store::getLocationStore));
        int[][] result = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            Store store = stores.get(i);
            result[i][0] = store.getLocationStore();
            result[i][1] = store.getTenges();
        }
        return result;
    }
    
    /**
     * Metodo para ordenadar por localizacionde menor a mayor.[location,tenges]
     */
    public int[][] robots(){
        Collections.sort(robots, Comparator.comparingInt(Robot::getCurrentLocationRobot));
        int[][] result = new int[robots.size()][1];
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            result[i][0] = robot.getCurrentLocationRobot();
        }
        return result;
    }
    
    /**
     * Metodo para hacer visible la ruta
     */
    public void makeVisible(){
        this.isVisible = true;
    }
    
    /**
     * Metodo para hacer invisible la ruta
     */
    public void makeInvisible(){
        this.isVisible = false;
    }
    
    /**
     * Metodo para terminar el simulador
     */
    public void finish(){
        
        profit();
        stores.size();
        robots.size();
        simulationRunning = false;
    }
    
    /**
     * Metodo para indicar si se logro realizar la ultima operacion.
     */
    public boolean oK(){
        return lastOperationSuccess;
    }
}
