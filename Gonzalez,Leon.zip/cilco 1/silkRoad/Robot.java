import java.util.Random;
import java.util.ArrayList;
/**
 * Robots 
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */

public class Robot{
    private String color;
    private int idRobot;
    private int currentLocationRobot;
    private int startLocationRobot;
    private Rectangle cabeza;
    private Rectangle cuello;
    private Rectangle cuerpo;
    private Rectangle arms;
    private static ArrayList<String> usedColors = new ArrayList<>();
    private static final String[] availableColors = {"red", "yellow", "blue","green", "magenta", "black", "darkGray", "lightGray", "orange", "cyan"};


    /**
     * Contructor de la clase Robot.
     * @param startLocationRobot ubicacion en X inical.
     */
    public Robot(int startLocationRobot){
        
        this.color = unicoColor();
        this.currentLocationRobot = 0;
        this.startLocationRobot = startLocationRobot;
        
        cabeza = new Rectangle();
        arms = new Rectangle();
        cuello = new Rectangle();
        cuerpo = new Rectangle();
        
        cabeza.changeColor(color);
        cuello.changeColor(color);
        arms.changeColor(color);
        cuerpo.changeColor(color);
    
        cabeza.changeSize(50,50);
        cuello.changeSize(25,25);
        cuerpo.changeSize(90,90);
        arms.changeSize(20,150);
        
        cabeza.moveVertical(40);
        cuello.moveVertical(75);
        cuerpo.moveVertical(100);
        arms.moveVertical(125);
        
        cabeza.moveHorizontal(10);
        cuello.moveHorizontal(23);
        cuerpo.moveHorizontal(-9);
        arms.moveHorizontal(-38);
        
    }
    
    private String unicoColor() {
        Random random = new Random();
        //AIGEN
        String selectedColor;
        do {
            int index = random.nextInt(availableColors.length);
            selectedColor = availableColors[index];
        } while (usedColors.contains(selectedColor));
        
        usedColors.add(selectedColor);
        return selectedColor;
    }
    
    /**
     * Hace invisible el robot.
     * 
    */
    public void makeInvisible(){
        cabeza.makeInvisible();
        cuello.makeInvisible();
        cuerpo.makeInvisible();
        arms.makeInvisible();
        
    }
    
     /**
     * Hace visible el robot
     * 
    */
    public void makeVisible(){
        cabeza.makeVisible();
        cuello.makeVisible();
        cuerpo.makeVisible();
        arms.makeVisible();
    }
    
    public int getCurrentLocationRobot() {
        return currentLocationRobot;
    }
    
    public int getStartLocationRobot() {
        return startLocationRobot;
    }
    
    public void setCurrentLocationRobot(int currentLocationRobot) {
        this.currentLocationRobot = currentLocationRobot;
    }
    
    public void setStartLocationRobot(int startLocationRobot) {
        this.startLocationRobot = startLocationRobot;
    }
    
    /**
     * Muestra el robot.
     * 
    */
    public void showRobots(){
        makeInvisible();
        makeVisible();
    }
    
    public void move(int meters) {
        cabeza.moveHorizontal(meters );
        cuello.moveHorizontal(meters);
        cuerpo.moveHorizontal(meters);
        arms.moveHorizontal(meters);
    
       // Actualizar la ubicación actual del robot
        currentLocationRobot += meters;
    }
    
    public String getColor(){
        return color;
    }
}