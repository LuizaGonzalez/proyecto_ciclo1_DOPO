import java.util.ArrayList;
import java.util.Random;
/**
 * Tiendas para la ruta de seda
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */
public class Store{
    private int width;
    private int height;
    private String colorStore;
    private int LocationStore;
    private int tenges;
    private int currentTenges;
    private Rectangle tienda;
    private static ArrayList<String> usedColors = new ArrayList<>();
    private static final String[] availableColors = {"red", "yellow", "blue","green", "magenta", "black", "darkGray", "lightGray", "orange", "cyan"};

    /**
     * Contructor de la clase Store.
     * @param LocationStore posicion en x inicial.
     * @param tenges monedas iniciales.
     */
    public Store(int LocationStore, int tenges){
        this.width=30;
        this.height=40;
        this.LocationStore = LocationStore;
        this.tenges = tenges;
        this.currentTenges = tenges;
        this.colorStore = unicoColor();
        this.tienda = new Rectangle();
        tienda.changeSize(height,width);
        tienda.moveHorizontal(LocationStore);
        tienda.changeColor(colorStore);
    }
    
    private String unicoColor() {
        Random random = new Random();
        
        String selectedColor;
        //Aigen
        do {
            int index = random.nextInt(availableColors.length);
            selectedColor = availableColors[index];
        } while (usedColors.contains(selectedColor));
        
        usedColors.add(selectedColor);
        return selectedColor;
    }
    
    /**
     * obtiene la altura.
     */
    public int getHeight(){
        return height;
    }
    
    /**
     * obtiene el ancho.
     */
    public int getWidth(){
        return width; 
    }
    
    /**
     * Obtiene el color asignado.
     */
    public String getColorStore(){
        return colorStore;
    }
    
    /**Devuelve la posición de la tienda en la ruta.
     * 
     */
    public int getLocationStore(){
        return LocationStore;
    }
    
    /**Cambia la ubicación.
     * 
     */
    public void setLocationStore(int newLocation){
        this.LocationStore = newLocation;
    }
    
    /**Obtiene la cantidad total de tenges acumulados.
     * 
     */
    public int getTenges() {
        return tenges;
    }
    
    /**Establece la cantidad total de tenges.
     * @param tenges monedas que quiere actualizar.
     */
    public void setTenges(int tenges) {
        this.tenges = tenges;
    }
    
    /**Obtiene la cantidad actual de tenges disponibles.
     * 
     */
    public int getCurrentTenges() {
        return currentTenges;
    }
    
    /**Cambia la cantidad actual de tenges disponibles.
     * @param currentTenges monedas actuales.
     */
    public void setCurrentTenges(int currentTenges) {
        this.currentTenges = currentTenges;
    }
    
    /**Establece la cantidad de tenges a agregar.
     * @param montoTenges monedas que se quiere añadir.
     */
    public void addTenges(int montoTenges){
       this.currentTenges += montoTenges;
    }
    
     /**Cambia el tamaño de la tienda
     * @param newHeight nueva altura de la tienda.
     * @param newWidth  nuevo ancho de la tienda.
     */
    public void changeSize(int newHeight , int newWidth){
        height = newHeight;
        width = newWidth;
        tienda.changeSize(newHeight,newWidth);
    }
 
}