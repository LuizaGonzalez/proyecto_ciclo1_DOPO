import java.util.Random;
import java.util.ArrayList;
/**
 * Robots 
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */

public class Robot{
    private String color;
    private int currentLocationRobot;
    private int startLocationRobot;
    private Rectangle cabeza;
    private Rectangle cuello;
    private Rectangle cuerpo;
    private Rectangle arms;
    private static ArrayList<String> usedColors = new ArrayList<>();
    private static final String[] availableColors = {"red", "yellow", "blue","green", "magenta", "black", "darkGray", "lightGray", "orange", "cyan"};


    /**
     * Contructor de la clase Robot.
     * @param startLocationRobot ubicacion en X inical.
     */
    public Robot(int startLocationRobot){
        
        this.color = unicoColor();
        this.currentLocationRobot = startLocationRobot;
        this.startLocationRobot = startLocationRobot;
        
        cabeza = new Rectangle();
        arms = new Rectangle();
        cuello = new Rectangle();
        cuerpo = new Rectangle();
        
        cabeza.changeColor(color);
        cuello.changeColor(color);
        arms.changeColor(color);
        cuerpo.changeColor(color);
        
        cabeza.changeSize(15,15);       
        cuello.changeSize(8,8);         
        cuerpo.changeSize(27,27);       
        arms.changeSize(6,45);          
        
        cabeza.moveVertical(0);        
        cuello.moveVertical(13);        
        cuerpo.moveVertical(20);        
        arms.moveVertical(23);          
        
        cabeza.moveHorizontal(startLocationRobot + 3);       
        cuello.moveHorizontal( startLocationRobot + 7);       
        cuerpo.moveHorizontal(startLocationRobot-3);      
        arms.moveHorizontal(startLocationRobot -11);       
    }
    
    /**
     * Metodo que hace que los robots no tengan colores repetidos.
     */
    private String unicoColor() {
        Random random = new Random();
        //AIGEN
        String selectedColor;
        do {
            int index = random.nextInt(availableColors.length);
            selectedColor = availableColors[index];
        } while (usedColors.contains(selectedColor));
        
        usedColors.add(selectedColor);
        return selectedColor;
    }
    
    /**
     * Hace invisible el robot.
     * 
    */
    public void makeInvisible(){
        cabeza.makeInvisible();
        cuello.makeInvisible();
        cuerpo.makeInvisible();
        arms.makeInvisible();
        
    }
    
     /**
     * Hace visible el robot
     * 
    */
    public void makeVisible(){
        cabeza.makeVisible();
        cuello.makeVisible();
        cuerpo.makeVisible();
        arms.makeVisible();
    }
    
    /**
     * Metodo que obtiene la posicion actual de un robot.
     */
    public int getCurrentLocationRobot() {
        return currentLocationRobot;
    }
    
    /**
     * Metodo que obtiene la posicion inicial de un robot.
     */
    public int getStartLocationRobot() {
        return startLocationRobot;
    }
    
    /**
     * Metodo que modifica la posicion actual de un robot.
     * @param currentLocationRobot posicion actual de un robot.
     */
    public void setCurrentLocationRobot(int currentLocationRobot) {
        this.currentLocationRobot = currentLocationRobot;
    }
    
    /**
     * Metodo que modifica la posicion inicial de un robot.
     * @param startLocationRobot posicion inicial de un robot.
     */
    public void setStartLocationRobot(int startLocationRobot) {
        this.startLocationRobot = startLocationRobot;
    }
    
    /**
     * Muestra el robot.
     * 
    */
    public void showRobots(){
        makeInvisible();
        makeVisible();
    }
    
    /**
     * Metodo que mueve un robot de una posicion actual a otra posicion dependiendo de lo metros.
     * @param meters metros que se va a mover el robot.
     */
    public void move(int meters) {
        int newPosition = currentLocationRobot + meters;
        
        cabeza.moveHorizontal(meters );
        cuello.moveHorizontal(meters);
        cuerpo.moveHorizontal(meters);
        arms.moveHorizontal(meters);
    
        currentLocationRobot = newPosition;
    }
    
    /**
     * Metodo ue obtiene el color de un robot.
     */
    public String getColor(){
        return color;
    }
}